package com.doranco.entities;

public class Ramette {

}
