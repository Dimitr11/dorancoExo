package com.doranco.entities;

import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {

		List<Lot> listLots = new ArrayList<Lot>();

		//Articles a1 = new Articles(0, "stylo", 15, 1);

		// a1.setListLots(listLots);
		Articles s1 = new Stylo("BLEU",0, "stylo", 15, 1);
		Lot l1 = new Lot(0, "lot stylos", 15, s1);
		
		s1.setLots((new ArrayList<Lot>()).add(l1));
		listLots.add(l1);
	
		// System.out.println(listLots);
		//System.out.println(a1);
		System.out.println(l1);
		System.out.println(s1);
		System.out.println("----------");
		System.out.println("Prix:"+ s1.calculerPrix(2, s1.getPrixArticle()));
		System.out.println("Prix lot:" + l1.prixLot(2, s1));
		

	}

}
