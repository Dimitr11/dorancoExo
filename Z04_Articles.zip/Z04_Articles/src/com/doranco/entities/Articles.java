package com.doranco.entities;

import java.util.List;

public class Articles {

	private int reference;
	private String nom;
	private int prixArticle;
	private int nbArticles;
	private boolean lots;
	//private List<Lot> listLots;

	public double calculerPrix(int nbArticles, int prixArticle) {

		return nbArticles * prixArticle;
	}

	public Articles() {
	}

	public Articles(int reference, String nom, int prixArticle, int nbArticles) {
		super();
		this.reference = reference;
		this.nom = nom;
		this.prixArticle = prixArticle;
		this.nbArticles = nbArticles;
	}

	public Articles(int reference, String nom, int prixArticle, int nbArticles, Boolean lots) {
		super();
		this.reference = reference;
		this.nom = nom;
		this.prixArticle = prixArticle;
		this.nbArticles = nbArticles;
		this.lots = lots;
	}

	/**
	 * @return the prixArticle
	 */
	public int getPrixArticle() {
		return prixArticle;
	}

	/**
	 * @param b the lots to set
	 */
	public void setLots(boolean b) {
		this.lots = b;
	}

	/**
	 * @param listLots the listLots to set
	 */
//	public void setListLots(List<Lot> listLots) {
//		this.listLots = listLots;
//	}

	@Override
	public String toString() {
		return "Articles [reference=" + reference + ", nom=" + nom + ", prixArticle=" + prixArticle + ", nbArticles="
				+ nbArticles + ", lots=" + lots + "]";
	}

}
