package com.doranco.entities;

public class Stylo extends Articles{

	private String couleur;

	public Stylo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Stylo(int reference, String nom, int prixArticle, int nbArticles, Boolean lots) {
		super(reference, nom, prixArticle, nbArticles, lots);
		// TODO Auto-generated constructor stub
	}

	public Stylo(int reference, String nom, int prixArticle, int nbArticles) {
		super(reference, nom, prixArticle, nbArticles);
		// TODO Auto-generated constructor stub
	}

	public Stylo(String couleur,int reference, String nom, int prixArticle, int nbArticles) {
		super(reference, nom, prixArticle, nbArticles);
		this.couleur = couleur;
	}

	
	
	/**
	 * @return the couleur
	 */
	public String getCouleur() {
		return couleur;
	}

	/**
	 * @param couleur the couleur to set
	 */
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}

	@Override
	public String toString() {
		return "Stylo [couleur=" + couleur + ", getPrixArticle()=" + getPrixArticle() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}

	
	
}
