package com.doranco.entities;

public class Lot {
	
	private int referenceLot;
	private String nomLot;
	private int nbArticles;
	private Articles article;
	
	public double prixLot(int nbArticle, Articles article) {
		
		return nbArticles * article.getPrixArticle();
	}
	
	
	/**
	 * @return the nomLot
	 */
	public String getNomLot() {
		return nomLot;
	}


	public Lot() {
		super();
	}
	public Lot(int referenceLot, String nomLot, int nbArticles, Articles article) {
		super();
		this.referenceLot = referenceLot;
		this.nomLot = nomLot;
		this.nbArticles = nbArticles;
		this.article = article;
	}
	@Override
	public String toString() {
		return "Lot [referenceLot=" + referenceLot + ", nomLot=" + nomLot + ", nbArticles=" + nbArticles + ", article="
				+ article + "]";
	}
	
	
	

}
